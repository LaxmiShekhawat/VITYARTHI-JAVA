# USAGE.md

## Sample Menu Operations
1. Manage Students
   - Add student: Enter details (id, regNo, name, email)
   - List students
   - Update/deactivate student
   - Print profile/transcript
2. Manage Courses
   - Add course: code, title, credits, instructor, semester, department
   - List/search/filter courses
   - Update/deactivate course
3. Enrollment & Grades
   - Enroll/unenroll student in course
   - Record marks, compute grade/GPA
   - Print transcript
4. Import/Export Data
   - Import students/courses from CSV
   - Export data to CSV
5. Backup & Reports
   - Backup exported files
   - Show backup size (recursive)
   - GPA distribution report

## Sample Data Files
- Place sample CSVs in `test-data/`
- Example: `students.csv`, `courses.csv`

## Sample CSV Format
### students.csv
id,regNo,fullName,email
S1,21BCE001,Muskan Sharma,muskan@vit.edu
S2,21BCE002,Arjun Patel,arjun@vit.edu

### courses.csv
code,title,credits,instructor,semester,department
CS101,Intro to CS,4,Dr. Rao,SPRING,CSE
MA201,Discrete Math,3,Dr. Singh,FALL,Maths
