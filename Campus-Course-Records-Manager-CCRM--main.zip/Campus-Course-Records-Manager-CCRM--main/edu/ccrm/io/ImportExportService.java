package edu.ccrm.io;

import edu.ccrm.domain.Student;
import edu.ccrm.domain.Course;
import java.util.List;

public interface ImportExportService {
    List<Student> importStudents(String filePath);
    List<Course> importCourses(String filePath);
    void exportStudents(List<Student> students, String filePath);
    void exportCourses(List<Course> courses, String filePath);
}
