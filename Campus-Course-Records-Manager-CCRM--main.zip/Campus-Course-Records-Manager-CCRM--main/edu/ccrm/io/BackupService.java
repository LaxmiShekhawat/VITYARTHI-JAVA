package edu.ccrm.io;

public interface BackupService {
    void backupData(String sourceDir, String backupDir);
    long computeBackupSize(String backupDir);
}
