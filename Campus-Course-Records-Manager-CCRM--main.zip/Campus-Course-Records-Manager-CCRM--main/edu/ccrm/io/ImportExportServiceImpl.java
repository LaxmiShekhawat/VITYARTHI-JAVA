package edu.ccrm.io;

import edu.ccrm.domain.Student;
import edu.ccrm.domain.Course;
import java.nio.file.*;
import java.util.*;
import java.io.*;
import java.util.stream.Collectors;

public class ImportExportServiceImpl implements ImportExportService {
    @Override
    public List<Student> importStudents(String filePath) {
        List<Student> students = new ArrayList<>();
        try {
            List<String> lines = Files.readAllLines(Paths.get(filePath));
            for (int i = 1; i < lines.size(); i++) { // skip header
                String[] parts = lines.get(i).split(",");
                students.add(new edu.ccrm.domain.Student(parts[0], parts[1], parts[2], parts[3]));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return students;
    }
    @Override
    public List<Course> importCourses(String filePath) {
        List<Course> courses = new ArrayList<>();
        try {
            List<String> lines = Files.readAllLines(Paths.get(filePath));
            for (int i = 1; i < lines.size(); i++) {
                String[] parts = lines.get(i).split(",");
                courses.add(new edu.ccrm.domain.Course(
                    new edu.ccrm.domain.CourseCode(parts[0]),
                    parts[1],
                    Integer.parseInt(parts[2]),
                    null, // instructor
                    edu.ccrm.domain.Semester.valueOf(parts[4]),
                    parts[5]
                ));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return courses;
    }
    @Override
    public void exportStudents(List<Student> students, String filePath) {
        try {
            List<String> lines = new ArrayList<>();
            lines.add("id,regNo,fullName,email");
            for (Student s : students) {
                lines.add(String.join(",", s.getId(), s.getRegNo(), s.getFullName(), s.getEmail()));
            }
            Files.write(Paths.get(filePath), lines);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void exportCourses(List<Course> courses, String filePath) {
        try {
            List<String> lines = new ArrayList<>();
            lines.add("code,title,credits,instructor,semester,department");
            for (Course c : courses) {
                lines.add(String.join(",",
                    c.getCode().getCode(),
                    c.getTitle(),
                    String.valueOf(c.getCredits()),
                    c.getInstructor() != null ? c.getInstructor().getFullName() : "",
                    c.getSemester().name(),
                    c.getDepartment()
                ));
            }
            Files.write(Paths.get(filePath), lines);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
