package edu.ccrm.io;

import java.nio.file.*;
import java.io.IOException;

public class BackupServiceImpl implements BackupService {
    @Override
    public void backupData(String sourceDir, String backupDir) {
        try {
            Path src = Paths.get(sourceDir);
            Path backup = Paths.get(backupDir);
            if (!Files.exists(backup)) Files.createDirectories(backup);
            Files.walk(src).forEach(path -> {
                try {
                    Path dest = backup.resolve(src.relativize(path));
                    if (Files.isDirectory(path)) {
                        if (!Files.exists(dest)) Files.createDirectories(dest);
                    } else {
                        Files.copy(path, dest, StandardCopyOption.REPLACE_EXISTING);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @Override
    public long computeBackupSize(String backupDir) {
        final long[] size = {0};
        try {
            Files.walk(Paths.get(backupDir)).forEach(path -> {
                if (Files.isRegularFile(path)) {
                    try {
                        size[0] += Files.size(path);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
        return size[0];
    }
}
