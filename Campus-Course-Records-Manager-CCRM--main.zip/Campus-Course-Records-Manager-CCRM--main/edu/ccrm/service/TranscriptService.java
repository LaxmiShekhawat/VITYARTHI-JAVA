package edu.ccrm.service;

import edu.ccrm.domain.Transcript;
import edu.ccrm.domain.Student;

public interface TranscriptService {
    Transcript getTranscript(Student student);
}
