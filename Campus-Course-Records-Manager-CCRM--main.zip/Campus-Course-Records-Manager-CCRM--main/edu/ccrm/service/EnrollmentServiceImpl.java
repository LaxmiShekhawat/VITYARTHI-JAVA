package edu.ccrm.service;

import edu.ccrm.domain.*;
import edu.ccrm.util.DuplicateEnrollmentException;
import edu.ccrm.util.MaxCreditLimitExceededException;
import java.util.*;

public class EnrollmentServiceImpl implements EnrollmentService {
    private final List<Enrollment> enrollments = new ArrayList<>();
    private static final int MAX_CREDITS = 24;
    @Override
    public void enroll(Student student, Course course) {
        for (Enrollment e : enrollments) {
            if (e.getStudent().equals(student) && e.getCourse().equals(course)) {
                throw new RuntimeException(new DuplicateEnrollmentException("Already enrolled."));
            }
        }
        int semesterCredits = enrollments.stream()
            .filter(e -> e.getStudent().equals(student) && e.getCourse().getSemester() == course.getSemester())
            .mapToInt(e -> e.getCourse().getCredits()).sum();
        if (semesterCredits + course.getCredits() > MAX_CREDITS) {
            throw new RuntimeException(new MaxCreditLimitExceededException("Max credits exceeded."));
        }
        Enrollment enrollment = new Enrollment(student, course);
        enrollments.add(enrollment);
        student.getTranscript().addEnrollment(enrollment);
        student.enrollCourse(course);
    }
    @Override
    public void unenroll(Student student, Course course) {
        enrollments.removeIf(e -> e.getStudent().equals(student) && e.getCourse().equals(course));
        student.unenrollCourse(course);
    }
    @Override
    public void recordMarks(Student student, Course course, int marks) {
        for (Enrollment e : enrollments) {
            if (e.getStudent().equals(student) && e.getCourse().equals(course)) {
                e.setMarks(marks);
                return;
            }
        }
    }
}
