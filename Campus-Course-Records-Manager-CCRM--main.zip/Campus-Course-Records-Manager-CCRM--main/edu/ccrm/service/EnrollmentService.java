package edu.ccrm.service;

import edu.ccrm.domain.Enrollment;
import edu.ccrm.domain.Student;
import edu.ccrm.domain.Course;

public interface EnrollmentService {
    void enroll(Student student, Course course);
    void unenroll(Student student, Course course);
    void recordMarks(Student student, Course course, int marks);
}
