package edu.ccrm.service;

import edu.ccrm.domain.Student;
import edu.ccrm.domain.Transcript;

public class TranscriptServiceImpl implements TranscriptService {
    @Override
    public Transcript getTranscript(Student student) {
        return student.getTranscript();
    }
}
