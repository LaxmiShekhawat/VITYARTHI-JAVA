package edu.ccrm.service;

import edu.ccrm.domain.Course;
import edu.ccrm.domain.CourseCode;
import edu.ccrm.domain.Instructor;
import edu.ccrm.domain.Semester;
import java.util.*;
import java.util.stream.Collectors;

public class CourseServiceImpl implements CourseService {
    private final Map<String, Course> courses = new HashMap<>();
    @Override
    public void addCourse(Course course) {
        courses.put(course.getCode().getCode(), course);
    }
    @Override
    public List<Course> listCourses() {
        return new ArrayList<>(courses.values());
    }
    @Override
    public Course findByCode(String code) {
        return courses.get(code);
    }
    @Override
    public void updateCourse(Course course) {
        courses.put(course.getCode().getCode(), course);
    }
    @Override
    public void deactivateCourse(String code) {
        Course c = courses.get(code);
        if (c != null) c.setTitle(c.getTitle() + " (Inactive)");
    }
    // Stream API search/filter
    public List<Course> filterByInstructor(String instructorName) {
        return courses.values().stream()
            .filter(c -> c.getInstructor() != null && c.getInstructor().getFullName().equalsIgnoreCase(instructorName))
            .collect(Collectors.toList());
    }
    public List<Course> filterByDepartment(String department) {
        return courses.values().stream()
            .filter(c -> c.getDepartment().equalsIgnoreCase(department))
            .collect(Collectors.toList());
    }
    public List<Course> filterBySemester(Semester semester) {
        return courses.values().stream()
            .filter(c -> c.getSemester() == semester)
            .collect(Collectors.toList());
    }
}
