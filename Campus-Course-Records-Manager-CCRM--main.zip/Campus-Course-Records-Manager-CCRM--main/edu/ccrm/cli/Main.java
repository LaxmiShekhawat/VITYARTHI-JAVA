package edu.ccrm.cli;

import edu.ccrm.config.AppConfig;

public class Main {
    public static void main(String[] args) {
        // Load config (Singleton)
        AppConfig config = AppConfig.getInstance();
        // Print platform note (Java SE vs ME vs EE)
        System.out.println(config.getPlatformNote());
        // Start CLI menu
        CLI cli = new CLI();
        cli.start();
    }
}
