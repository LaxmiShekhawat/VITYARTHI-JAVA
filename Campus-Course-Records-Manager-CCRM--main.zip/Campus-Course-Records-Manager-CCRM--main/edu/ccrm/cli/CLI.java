package edu.ccrm.cli;

import java.util.Scanner;

public class CLI {
    private edu.ccrm.service.StudentService studentService = new edu.ccrm.service.StudentServiceImpl();
    private edu.ccrm.service.CourseService courseService = new edu.ccrm.service.CourseServiceImpl();
    private edu.ccrm.service.EnrollmentService enrollmentService = new edu.ccrm.service.EnrollmentServiceImpl();
    private edu.ccrm.service.TranscriptService transcriptService = new edu.ccrm.service.TranscriptServiceImpl();
    private edu.ccrm.io.ImportExportService importExportService = new edu.ccrm.io.ImportExportServiceImpl();
    private edu.ccrm.io.BackupService backupService = new edu.ccrm.io.BackupServiceImpl();

    public void start() {
        Scanner sc = new Scanner(System.in);
        boolean running = true;
        while (running) {
            printMenu();
            String choice = sc.nextLine();
            switch (choice) {
                case "1":
                    manageStudents(sc);
                    break;
                case "2":
                    manageCourses(sc);
                    break;
                case "3":
                    manageEnrollmentGrades(sc);
                    break;
                case "4":
                    importExportData(sc);
                    break;
                case "5":
                    backupAndShowSize();
                    break;
                case "6":
                    showReports();
                    break;
                case "0":
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
        sc.close();
    }

    private void manageStudents(Scanner sc) {
        assert studentService != null : "StudentService must not be null";
        System.out.println("1. Add Student\n2. List Students\n3. Update Student\n4. Deactivate Student\n5. Print Profile\n6. Print Transcript");
        String choice = sc.nextLine();
    switch (choice) {
            case "1":
                System.out.print("Enter id, regNo, fullName, email (comma separated): ");
                String[] parts = sc.nextLine().split(",");
                studentService.addStudent(new edu.ccrm.domain.Student(parts[0], parts[1], parts[2], parts[3]));
                System.out.println("Student added.");
                break;
            case "2":
                for (edu.ccrm.domain.Student st : studentService.listStudents()) {
                    if (st instanceof edu.ccrm.domain.Person) {
                        System.out.println("(Person) " + st);
                    } else {
                        System.out.println(st);
                    }
                }
                break;
            case "3":
                System.out.print("Enter regNo to update: ");
                String regNo = sc.nextLine();
                edu.ccrm.domain.Student s = studentService.findByRegNo(regNo);
                if (s != null) {
                    System.out.print("Enter new fullName: ");
                    s = new edu.ccrm.domain.Student(s.getId(), s.getRegNo(), sc.nextLine(), s.getEmail());
                    studentService.updateStudent(s);
                    System.out.println("Updated.");
                }
                break;
            case "4":
                System.out.print("Enter regNo to deactivate: ");
                studentService.deactivateStudent(sc.nextLine());
                System.out.println("Deactivated.");
                break;
            case "5":
                System.out.print("Enter regNo: ");
                s = studentService.findByRegNo(sc.nextLine());
                if (s != null) System.out.println(s.getProfile());
                break;
            case "6":
                System.out.print("Enter regNo: ");
                s = studentService.findByRegNo(sc.nextLine());
                if (s != null) System.out.println(s.getTranscript());
                break;
        }
    }

    private void manageCourses(Scanner sc) {
        System.out.println("1. Add Course\n2. List Courses\n3. Update Course\n4. Deactivate Course\n5. Search/Filter");
        String choice = sc.nextLine();
        switch (choice) {
            case "1":
                System.out.print("Enter code, title, credits, semester, department (comma separated): ");
                String[] parts = sc.nextLine().split(",");
                courseService.addCourse(new edu.ccrm.domain.Course(
                    new edu.ccrm.domain.CourseCode(parts[0]),
                    parts[1],
                    Integer.parseInt(parts[2]),
                    null,
                    edu.ccrm.domain.Semester.valueOf(parts[3]),
                    parts[4]
                ));
                System.out.println("Course added.");
                break;
            case "2":
                courseService.listCourses().forEach(System.out::println);
                break;
            case "3":
                System.out.print("Enter code to update: ");
                String code = sc.nextLine();
                edu.ccrm.domain.Course c = courseService.findByCode(code);
                if (c != null) {
                    System.out.print("Enter new title: ");
                    c.setTitle(sc.nextLine());
                    courseService.updateCourse(c);
                    System.out.println("Updated.");
                }
                break;
            case "4":
                System.out.print("Enter code to deactivate: ");
                courseService.deactivateCourse(sc.nextLine());
                System.out.println("Deactivated.");
                break;
            case "5":
                System.out.print("Filter by (instructor/department/semester): ");
                String filter = sc.nextLine();
                if (filter.equalsIgnoreCase("instructor")) {
                    System.out.print("Enter instructor name: ");
                    ((edu.ccrm.service.CourseServiceImpl)courseService).filterByInstructor(sc.nextLine()).forEach(System.out::println);
                } else if (filter.equalsIgnoreCase("department")) {
                    System.out.print("Enter department: ");
                    ((edu.ccrm.service.CourseServiceImpl)courseService).filterByDepartment(sc.nextLine()).forEach(System.out::println);
                } else if (filter.equalsIgnoreCase("semester")) {
                    System.out.print("Enter semester (SPRING/SUMMER/FALL): ");
                    ((edu.ccrm.service.CourseServiceImpl)courseService).filterBySemester(edu.ccrm.domain.Semester.valueOf(sc.nextLine())).forEach(System.out::println);
                }
                break;
        }
    }

    private void manageEnrollmentGrades(Scanner sc) {
        System.out.println("1. Enroll\n2. Unenroll\n3. Record Marks");
        String choice = sc.nextLine();
        switch (choice) {
            case "1":
                System.out.print("Enter regNo, courseCode: ");
                String[] parts = sc.nextLine().split(",");
                edu.ccrm.domain.Student s = studentService.findByRegNo(parts[0]);
                edu.ccrm.domain.Course c = courseService.findByCode(parts[1]);
                if (s != null && c != null) {
                    try {
                        enrollmentService.enroll(s, c);
                        System.out.println("Enrolled.");
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                }
                break;
            case "2":
                System.out.print("Enter regNo, courseCode: ");
                parts = sc.nextLine().split(",");
                s = studentService.findByRegNo(parts[0]);
                c = courseService.findByCode(parts[1]);
                if (s != null && c != null) {
                    enrollmentService.unenroll(s, c);
                    System.out.println("Unenrolled.");
                }
                break;
            case "3":
                System.out.print("Enter regNo, courseCode, marks: ");
                parts = sc.nextLine().split(",");
                s = studentService.findByRegNo(parts[0]);
                c = courseService.findByCode(parts[1]);
                if (s != null && c != null) {
                    enrollmentService.recordMarks(s, c, Integer.parseInt(parts[2]));
                    System.out.println("Marks recorded.");
                }
                break;
        }
    }

    private void importExportData(Scanner sc) {
        System.out.println("1. Import Students\n2. Import Courses\n3. Export Students\n4. Export Courses");
        String choice = sc.nextLine();
        switch (choice) {
            case "1":
                System.out.print("Enter file path: ");
                importExportService.importStudents(sc.nextLine()).forEach(studentService::addStudent);
                System.out.println("Students imported.");
                break;
            case "2":
                System.out.print("Enter file path: ");
                importExportService.importCourses(sc.nextLine()).forEach(courseService::addCourse);
                System.out.println("Courses imported.");
                break;
            case "3":
                System.out.print("Enter file path: ");
                importExportService.exportStudents(studentService.listStudents(), sc.nextLine());
                System.out.println("Students exported.");
                break;
            case "4":
                System.out.print("Enter file path: ");
                importExportService.exportCourses(courseService.listCourses(), sc.nextLine());
                System.out.println("Courses exported.");
                break;
        }
    }

    private void backupAndShowSize() {
        String src = "f:/MUSKAN/Academics/VIT/Class Material/3rd YEAR/Java/test-data";
        String backupDir = "f:/MUSKAN/Academics/VIT/Class Material/3rd YEAR/Java/backup_" + java.time.LocalDate.now();
        backupService.backupData(src, backupDir);
        long size = backupService.computeBackupSize(backupDir);
        System.out.println("Backup completed. Total size: " + size + " bytes");
    }

    private void showReports() {
        // GPA distribution using Streams
        java.util.List<edu.ccrm.domain.Student> students = studentService.listStudents();
        java.util.Map<Integer, Long> gpaDist = students.stream()
            .collect(java.util.stream.Collectors.groupingBy(
                s -> (int)s.getTranscript().computeGPA(), java.util.stream.Collectors.counting()
            ));
        System.out.println("GPA Distribution:");
        gpaDist.forEach((gpa, count) -> System.out.println("GPA: " + gpa + " Count: " + count));
        // Top students
        students.stream()
            .sorted((a, b) -> Double.compare(b.getTranscript().computeGPA(), a.getTranscript().computeGPA()))
            .limit(3)
            .forEach(s -> System.out.println(s.getFullName() + " GPA: " + s.getTranscript().computeGPA()));
    }
    private void printMenu() {
        System.out.println("\n--- Campus Course & Records Manager ---");
        System.out.println("1. Manage Students");
        System.out.println("2. Manage Courses");
        System.out.println("3. Enrollment & Grades");
        System.out.println("4. Import/Export Data");
        System.out.println("5. Backup & Show Backup Size");
        System.out.println("6. Reports");
        System.out.println("0. Exit");
        System.out.print("Enter choice: ");
    }
}
