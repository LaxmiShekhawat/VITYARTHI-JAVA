package edu.ccrm.domain;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Student extends Person {
    private String regNo;
    private List<Course> enrolledCourses;
    private Transcript transcript;
    public Student(String id, String regNo, String fullName, String email) {
        super(id, fullName, email);
        this.regNo = regNo;
        this.enrolledCourses = new ArrayList<>();
        this.transcript = new Transcript(this);
    }
    public String getRegNo() { return regNo; }
    public List<Course> getEnrolledCourses() { return enrolledCourses; }
    public Transcript getTranscript() { return transcript; }
    public void enrollCourse(Course course) {
        enrolledCourses.add(course);
    }
    public void unenrollCourse(Course course) {
        enrolledCourses.remove(course);
    }
    @Override
    public String getProfile() {
        return String.format("Student: %s\nRegNo: %s\nEmail: %s\nStatus: %s\nEnrolled: %d\nCreated: %s", fullName, regNo, email, active ? "Active" : "Inactive", enrolledCourses.size(), createdAt);
    }
    @Override
    public String toString() {
        return getProfile();
    }
}
