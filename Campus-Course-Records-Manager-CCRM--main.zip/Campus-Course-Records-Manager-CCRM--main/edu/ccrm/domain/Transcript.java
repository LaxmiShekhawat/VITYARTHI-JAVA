package edu.ccrm.domain;

import java.util.ArrayList;
import java.util.List;

public class Transcript {
    private Student student;
    private List<Enrollment> enrollments;
    public Transcript(Student student) {
        this.student = student;
        this.enrollments = new ArrayList<>();
    }
    public void addEnrollment(Enrollment e) {
        enrollments.add(e);
    }
    public double computeGPA() {
        if (enrollments.isEmpty()) return 0.0;
        int totalCredits = 0;
        int totalPoints = 0;
        for (Enrollment e : enrollments) {
            totalCredits += e.getCourse().getCredits();
            totalPoints += e.getGrade().getPoints() * e.getCourse().getCredits();
        }
        return totalCredits == 0 ? 0.0 : (double) totalPoints / totalCredits;
    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Transcript for ").append(student.getFullName()).append("\n");
        for (Enrollment e : enrollments) {
            sb.append(e.toString()).append("\n");
        }
        sb.append(String.format("GPA: %.2f", computeGPA()));
        return sb.toString();
    }
}
