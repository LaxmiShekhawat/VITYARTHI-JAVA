package edu.ccrm.domain;

import java.time.LocalDate;

public class Enrollment {
    private Student student;
    private Course course;
    private LocalDate enrolledOn;
    private Grade grade;
    private int marks;
    public Enrollment(Student student, Course course) {
        this.student = student;
        this.course = course;
        this.enrolledOn = LocalDate.now();
    }
    public Student getStudent() { return student; }
    public Course getCourse() { return course; }
    public LocalDate getEnrolledOn() { return enrolledOn; }
    public Grade getGrade() { return grade; }
    public int getMarks() { return marks; }
    public void setMarks(int marks) {
        this.marks = marks;
        this.grade = computeGrade(marks);
    }
    private Grade computeGrade(int marks) {
        if (marks >= 90) return Grade.S;
        if (marks >= 80) return Grade.A;
        if (marks >= 70) return Grade.B;
        if (marks >= 60) return Grade.C;
        if (marks >= 50) return Grade.D;
        if (marks >= 40) return Grade.E;
        return Grade.F;
    }
    @Override
    public String toString() {
        return String.format("%s - %s: %d (%s)", student.getFullName(), course.getCode(), marks, grade);
    }
}
