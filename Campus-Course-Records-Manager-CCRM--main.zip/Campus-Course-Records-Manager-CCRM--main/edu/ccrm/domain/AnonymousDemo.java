package edu.ccrm.domain;

public class AnonymousDemo {
    public void run() {
        Runnable r = new Runnable() {
            @Override
            public void run() {
                System.out.println("Anonymous inner class running");
            }
        };
        r.run();
    }
}
