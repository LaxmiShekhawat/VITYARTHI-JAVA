package edu.ccrm.util;

import java.nio.file.*;
import java.io.IOException;

public class BackupUtils {
    // Recursively list files by depth
    public static void listFilesByDepth(Path dir, int depth) {
        if (depth < 0) return;
        try {
            Files.list(dir).forEach(path -> {
                System.out.println("Depth " + depth + ": " + path.getFileName());
                if (Files.isDirectory(path)) {
                    listFilesByDepth(path, depth + 1);
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
