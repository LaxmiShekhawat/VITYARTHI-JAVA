package edu.ccrm.util;

public interface DiamondProblemDemo {
    default void show() {
        System.out.println("Default from DiamondProblemDemo");
    }
}

interface DiamondProblemDemo2 {
    default void show() {
        System.out.println("Default from DiamondProblemDemo2");
    }
}

class DiamondProblemImpl implements DiamondProblemDemo, DiamondProblemDemo2 {
    @Override
    public void show() {
        DiamondProblemDemo.super.show(); // Explicit override
    }
}
