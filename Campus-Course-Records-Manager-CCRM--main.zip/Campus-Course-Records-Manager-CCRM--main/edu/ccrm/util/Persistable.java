package edu.ccrm.util;

public interface Persistable {
    void save();
    void load();
}
