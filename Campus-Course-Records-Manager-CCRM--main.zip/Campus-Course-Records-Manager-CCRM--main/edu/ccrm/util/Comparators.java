package edu.ccrm.util;

import java.util.Comparator;
import edu.ccrm.domain.Course;

public class Comparators {
    // Lambda comparator for sorting courses by code
    public static Comparator<Course> byCode = (a, b) -> a.getCode().getCode().compareTo(b.getCode().getCode());
}
