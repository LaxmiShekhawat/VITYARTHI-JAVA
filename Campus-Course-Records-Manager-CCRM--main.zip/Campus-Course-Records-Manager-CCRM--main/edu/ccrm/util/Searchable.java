package edu.ccrm.util;

public interface Searchable<T> {
    boolean matches(T criteria);
}
