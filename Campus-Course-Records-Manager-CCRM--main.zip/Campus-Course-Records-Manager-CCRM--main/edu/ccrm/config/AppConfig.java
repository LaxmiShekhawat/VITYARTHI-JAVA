package edu.ccrm.config;

public class AppConfig {
    private static AppConfig instance;
    private String dataFolderPath = "data";
    private AppConfig() {}
    public static AppConfig getInstance() {
        if (instance == null) {
            instance = new AppConfig();
        }
        return instance;
    }
    public String getDataFolderPath() {
        return dataFolderPath;
    }
    public String getPlatformNote() {
        return "Java SE: Standard Edition for desktop/server apps. Java ME: Micro Edition for embedded/mobile. Java EE: Enterprise Edition for web/services.";
    }
}
